from django.contrib import admin
from django.forms import Textarea
from django.db import models
from .models import Category, SubCategory, Question, Answer

class AnswerInline(admin.TabularInline):
    model = Answer
    extra = 1
    formfield_overrides = {
        models.TextField: {'widget': Textarea(attrs={'rows': 4, 'cols': 40})},
    }

class QuestionAdmin(admin.ModelAdmin):
    inlines = [AnswerInline]

admin.site.register(Category)
admin.site.register(SubCategory)
admin.site.register(Question, QuestionAdmin)
