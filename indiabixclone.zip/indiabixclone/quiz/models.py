from django.db import models

class Category(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return self.name

class SubCategory(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return self.name

class Question(models.Model):
    subcategory = models.ForeignKey(SubCategory, on_delete=models.CASCADE)
    question_text = models.TextField()
    pub_date = models.DateTimeField('date published')
    image = models.ImageField(upload_to='question_images/', null=True, blank=True)  # Add image field

    def __str__(self):
        return self.question_text

class Answer(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    answer_text = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)
    explanation = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.answer_text
