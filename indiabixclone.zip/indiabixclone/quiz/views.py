from django.shortcuts import render, get_object_or_404
from .models import Category, SubCategory, Question

def index(request):
    categories = Category.objects.all()
    return render(request, 'index.html', {'categories': categories})

def category_detail(request, category_id):
    category = get_object_or_404(Category, pk=category_id)
    subcategories = SubCategory.objects.filter(category=category)
    return render(request, 'category_detail.html', {'category': category, 'subcategories': subcategories})

def subcategory_detail(request, subcategory_id):
    subcategory = get_object_or_404(SubCategory, pk=subcategory_id)
    questions = Question.objects.filter(subcategory=subcategory).prefetch_related('answer_set')
    
    questions_with_correct_answers = []
    for question in questions:
        correct_answer = question.answer_set.get(is_correct=True)
        questions_with_correct_answers.append({
            'question': question,
            'correct_answer_id': correct_answer.id,
            'correct_answer_explanation': correct_answer.explanation,
            'answers': question.answer_set.all()
        })
    
    return render(request, 'subcategory_detail.html', {
        'subcategory': subcategory,
        'questions_with_correct_answers': questions_with_correct_answers
    })
